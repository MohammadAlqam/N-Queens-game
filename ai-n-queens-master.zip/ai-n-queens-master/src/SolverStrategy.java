/**
 * Created by mrsfy on 05-Jun-17.
 */
public interface SolverStrategy {

public int[] solve();

}
